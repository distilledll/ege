from src.config import Settings
from src.capture import CaptureManager
from src.scheduler import Scheduler
from src.inference import InferencePool
from src.render_tk import TkRender
from src.gui import MultiStreamApp
from loguru import logger
import argparse
import signal


def build_args():
    p = argparse.ArgumentParser(description="Multi stream frame-based player (RT-DETR)")
    p.add_argument("--config", type=str, default=None)
    p.add_argument("--urls", nargs="+", help="List of video urls or mp4 files")
    p.add_argument("--model", type=str, default="rtdetr.pt", help="Path or name of RT-DETR model (.pt)")
    p.add_argument("--device", type=str, default="cpu", help="Device: cpu or cuda:0")
    p.add_argument("--headless", action="store_true", help="OpenCV windows instead of tkinter (debug)")
    return p.parse_args()

def main():
    args = build_args()
    if not args.urls:
        print("Нет аргументов — запускаю пользовательский сценарий...")
        app = MultiStreamApp()
        app.run()

    else:
        cfg = Settings(_env_file=args.config) if args.config else Settings()
        logger.info("Starting with {} urls", len(args.urls))

        capture_mgr = CaptureManager(args.urls, cfg)
        inference_pool = InferencePool(num_workers=cfg.num_workers, cfg=cfg, model_path=args.model, device=args.device)
        # choose renderer: Tkinter by default, headless for debugging
        renderer = TkRender(cfg=cfg, urls=args.urls) if not args.headless else None
        scheduler = Scheduler(capture_mgr=capture_mgr, inference_pool=inference_pool, render=renderer, cfg=cfg)

        def shutdown(signum, frame):
            logger.info("Shutting down (signal {})", signum)
            scheduler.stop()
            capture_mgr.stop_all()
            inference_pool.stop()
            if renderer is not None:
                renderer.stop()
        signal.signal(signal.SIGINT, shutdown)
        signal.signal(signal.SIGTERM, shutdown)

        capture_mgr.start_all()
        if renderer is not None:
            renderer.start()
        inference_pool.start()
        scheduler.start()

if __name__ == "__main__":
    main()
