## Run project

### CPU local dev (no GPU)
``` bash
pip install -r requirements.txt
python3 main.py --urls sample1.mp4 sample2.mp4 --model path/to/rtdetr.pt --device cpu
```

### On server with GPU
``` bash
python3 main.py --urls rtsp://... rtsp://... --model path/to/rtdetr.pt --device cuda:0 --num-workers 2
```