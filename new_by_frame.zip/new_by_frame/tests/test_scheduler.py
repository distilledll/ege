import pytest
from new_by_frame.src.config import Settings
from new_by_frame.src.capture import CaptureManager
from new_by_frame.src.inference import InferencePool
from new_by_frame.src.scheduler import Scheduler
from new_by_frame.src.render import RenderWorker
import time
import os

def test_integration_with_local_mp4(tmp_path):
    # create a tiny mp4 or use existing file path env var; test is smoke only
    cfg = Settings()
    sample = os.environ.get("SAMPLE_MP4")
    if not sample:
        pytest.skip("SAMPLE_MP4 not provided")
    cm = CaptureManager([sample], cfg)
    pool = InferencePool(num_workers=1, cfg=cfg)
    render = RenderWorker(cfg=cfg, headless=True)
    sched = Scheduler(capture_mgr=cm, inference_pool=pool, render=render, cfg=cfg)
    cm.start_all()
    pool.start()
    render.start()
    sched.start()
    time.sleep(2.0)
    sched.stop()
    cm.stop_all()
    pool.stop()
    render.stop()
    assert True
