import time
from loguru import logger


class Metrics:
    def __init__(self):
        self.t0 = time.time()

    def log(self, msg: str):
        logger.debug("[metrics] {}", msg)
