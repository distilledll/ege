import threading
import queue
import cv2
import time
import os
from loguru import logger
from typing import Dict, List
from .models import FramePacket
from .utils import now_ts, resize_keep_aspect
from .config import Settings


class CaptureWorker(threading.Thread):
    def __init__(self, url: str, out_q: queue.Queue, cfg: Settings):
        super().__init__(daemon=False, name=f"Capture-{url}")
        self.url = url
        self.out_q = out_q
        self.cfg = cfg
        self._stop_event = threading.Event()
        self._cap = None
        self.seq = 0

    def open_cap(self):
        if self._cap:
            return True
        # if url is local file, resolve absolute and check existence
        if not (self.url.startswith("rtsp://") or self.url.startswith("http://") or self.url.startswith("https://")):
            if not os.path.isabs(self.url):
                candidate = os.path.join(os.getcwd(), self.url)
            else:
                candidate = self.url
            if not os.path.exists(candidate):
                logger.warning("Capture file not found: {} (cwd={})", self.url, os.getcwd())
                return False
            open_path = candidate
        else:
            open_path = self.url
        self._cap = cv2.VideoCapture(open_path)
        ok = self._cap.isOpened()
        if not ok:
            logger.warning("Failed to open capture: {} (tried {})", self.url, open_path)
            try:
                if self._cap:
                    self._cap.release()
            except Exception:
                pass
            self._cap = None
        return ok

    def run(self):
        backoff = self.cfg.reconnect_delay_initial
        while not self._stop_event.is_set():
            if not self.open_cap():
                # sleep and retry with exponential backoff
                time.sleep(backoff)
                backoff = min(backoff * 2, self.cfg.reconnect_delay_max)
                continue
            backoff = self.cfg.reconnect_delay_initial
            ret, frame = self._cap.read()
            if not ret:
                logger.warning("No frame from {} — releasing cap and retrying", self.url)
                try:
                    self._cap.release()
                except Exception:
                    pass
                self._cap = None
                time.sleep(0.1)
                continue
            frame = resize_keep_aspect(frame, self.cfg.frame_width)
            pkt = FramePacket(url=self.url, seq=self.seq, ts=now_ts(), frame=frame)
            self.seq += 1
            try:
                if self.out_q.full():
                    try:
                        _ = self.out_q.get_nowait()
                    except queue.Empty:
                        pass
                self.out_q.put_nowait(pkt)
            except queue.Full:
                logger.debug("Drop packet (full) {}", self.url)
            # small yield
            time.sleep(0.001)

    def stop(self):
        self._stop_event.set()
        if self._cap:
            try:
                self._cap.release()
            except Exception:
                pass

class CaptureManager:
    def __init__(self, urls: List[str], cfg: Settings):
        self.cfg = cfg
        self.urls = urls
        self.queues: Dict[str, queue.Queue] = {}
        self.workers: Dict[str, CaptureWorker] = {}
        for u in urls:
            q = queue.Queue(maxsize=self.cfg.frame_queue_maxsize)
            self.queues[u] = q
            self.workers[u] = CaptureWorker(url=u, out_q=q, cfg=cfg)

    def start_all(self):
        for w in self.workers.values():
            w.start()

    def stop_all(self):
        for w in self.workers.values():
            w.stop()
            w.join(timeout=2.0)

    def get_queue(self, url: str) -> queue.Queue:
        return self.queues[url]