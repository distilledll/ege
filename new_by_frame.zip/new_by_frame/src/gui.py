import tkinter as tk
from tkinter import filedialog, messagebox, scrolledtext
from functools import partial
from .engine import PipelineController
from .config import Settings


class MultiStreamApp:
    def __init__(self):
        self.cfg = Settings()
        self.root = tk.Tk()
        self.root.title("Multi-Stream RT-DETR Surveillance")
        self.root.geometry("1920x1080")
        
        # Handle window close
        self.root.protocol("WM_DELETE_WINDOW", self._on_closing)

        # pipeline controller
        self.controller = PipelineController(self.cfg)

        # UI layout: left pane controls, right canvas grid
        self._build_left_controls()
        self._build_video_grid()
    
    def _on_closing(self):
        """Handle window close event"""
        try:
            self._stop()
        except Exception:
            pass
        try:
            self.root.destroy()
        except Exception:
            pass
        try:
            self.root.quit()  # Force exit mainloop
        except Exception:
            pass

    def _build_left_controls(self):
        panel = tk.Frame(self.root, padx=8, pady=8, bg="#2e2e2e")
        panel.pack(side="left", fill="y")

        tk.Label(panel, text="Введите ссылки:", fg="white", bg="#2e2e2e").pack(anchor="w")

        self.src_text = scrolledtext.ScrolledText(panel, width=35, height=25)
        self.src_text.pack()

        tk.Button(panel, text="Добавить файл",
                  command=self._add_file).pack(fill="x", pady=4)
        
        # Filter classes section
        tk.Label(panel, text="Детектировать классы:", fg="white", bg="#2e2e2e").pack(anchor="w", pady=(10, 5))
        tk.Label(panel, text='(ID через запятую, напр: "0")', fg="gray", bg="#2e2e2e", font=("Arial", 8)).pack(anchor="w")
        
        self.class_filter_var = tk.StringVar(value="")
        self.class_filter_entry = tk.Entry(panel, textvariable=self.class_filter_var, width=25)
        self.class_filter_entry.pack(fill="x", pady=2)

        tk.Button(panel, text="Старт", bg="#1e8f1e", fg="white",
                  command=self._start).pack(fill="x", pady=4)

        tk.Button(panel, text="Стоп", bg="#b02020", fg="white",
                  command=self._stop).pack(fill="x", pady=4)

    def _build_video_grid(self):
        self.grid_frame = tk.Frame(self.root, bg="black")
        self.grid_frame.pack(side="right", fill="both", expand=True)

    def _add_file(self):
        files = filedialog.askopenfilenames(
            filetypes=[("Video Files", "*.mp4 *.avi *.mov")]
        )
        for f in files:
            self.src_text.insert(tk.END, f"\n{f}")

    def _start(self):
        urls = [
            line.strip() for line in self.src_text.get("1.0", tk.END).splitlines()
            if line.strip()
        ]
        if not urls:
            messagebox.showwarning("Ошибка", "Введите хотя бы одну ссылку")
            return

        # Stop existing pipeline if running
        self._stop()
        
        # Clear grid frame
        for widget in self.grid_frame.winfo_children():
            widget.destroy()
        
        # Update config with filter classes
        self.cfg.detect_classes = self.class_filter_var.get()
        
        # Recreate controller
        self.controller = PipelineController(self.cfg)

        try:
            self.controller.start(urls, self.grid_frame)
        except Exception as e:
            import traceback
            messagebox.showerror("Старт не удался", f"{str(e)}\n\n{traceback.format_exc()}")

    def _stop(self):
        try:
            if hasattr(self, 'controller') and self.controller:
                self.controller.stop()
        except Exception as e:
            pass  # Ignore errors during shutdown

    def run(self):
        self.root.mainloop()
