import threading
import queue
import time
from typing import List, Dict
from .capture import CaptureManager
from .inference import InferencePool
from .models import InferenceTask, InferenceResult
from .config import Settings
from loguru import logger

class Scheduler(threading.Thread):
    def __init__(self, capture_mgr: CaptureManager, inference_pool: InferencePool, render, cfg: Settings):
        super().__init__(daemon=True, name="Scheduler")
        self.capture_mgr = capture_mgr
        self.pool = inference_pool
        self.render = render
        self.cfg = cfg
        self.urls: List[str] = capture_mgr.urls
        self.running = threading.Event()
        self.processing: Dict[str, bool] = {u: False for u in self.urls}
        self.last_shown_seq: Dict[str, int] = {u: -1 for u in self.urls}
        self._lock = threading.Lock()

    def start(self):
        self.running.set()
        super().start()

    def stop(self):
        self.running.clear()

    def run(self):
        idx = 0
        urls = self.urls
        n = len(urls)
        results_q = self.pool.get_result_queue()
        while self.running.is_set():
            # drain result queue and forward to render, free processing flags
            try:
                while not results_q.empty():
                    res: InferenceResult = results_q.get_nowait()
                    self.processing[res.url] = False
                    self.last_shown_seq[res.url] = res.seq
                    self.render.push_result(res)
            except queue.Empty:
                pass

            # Scheduler round-robin
            u = urls[idx % n]
            idx += 1
            q = self.capture_mgr.get_queue(u)
            if q.empty():
                time.sleep(0.001)
                continue
            if self.processing.get(u, False):
                continue
            try:
                pkt = q.get_nowait()
            except queue.Empty:
                continue
            # sampling
            if (pkt.seq % self.cfg.process_every_nth_frame) != 0:
                continue
            # submit
            try:
                self.processing[u] = True
                self.pool.submit(InferenceTask(packet=pkt))
            except Exception as e:
                logger.exception("Failed to submit task: {}", e)
                self.processing[u] = False
            # soft yield, optionally switch after frames - simple strategy: iterate
            time.sleep(0.001)
        logger.info("Scheduler stopped")
