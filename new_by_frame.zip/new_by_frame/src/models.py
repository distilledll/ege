from dataclasses import dataclass
import numpy as np
from typing import Any


@dataclass
class FramePacket:
    url: str
    seq: int
    ts: float
    frame: np.ndarray

@dataclass
class InferenceTask:
    packet: FramePacket

@dataclass
class InferenceResult:
    url: str
    seq: int
    ts: float
    annotated_frame: Any
    metadata: dict
