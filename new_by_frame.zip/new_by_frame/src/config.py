from pydantic_settings import BaseSettings
from pydantic import Field
import os
from pathlib import Path


class Settings(BaseSettings):
    max_readers: int = Field(32, description="Max active VideoCapture")
    num_workers: int = Field(1, description="Inference worker processes")
    frame_queue_maxsize: int = Field(1)
    process_every_nth_frame: int = Field(1)
    switch_after_frames: int = Field(4)
    frame_width: int = Field(640)
    log_level: str = Field("INFO")
    reconnect_delay_initial: float = Field(1.0)
    reconnect_delay_max: float = Field(30.0)
    imgsz: int = Field(640)
    model_path: str = Field(default_factory=lambda: Settings._find_model(), description="Path to model file")
    device: str = Field(default="cpu", description="Device for inference")
    detect_classes: str = Field(default="", description="Comma-separated class IDs to detect, e.g. '0' for person only")

    @staticmethod
    def _find_model():
        """Auto-detect model path"""
        # Check in current directory and parent directories
        for base_dir in [Path.cwd(), Path.cwd().parent]:
            model_file = base_dir / "rtdetr-l.pt"
            if model_file.exists():
                return str(model_file)
        # Default if not found
        return "rtdetr-l.pt"

    class Config:
        env_file = ".env"
