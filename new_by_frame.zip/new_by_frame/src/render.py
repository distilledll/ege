import threading
import queue
import cv2
from .models import InferenceResult
from .config import Settings
from loguru import logger


class RenderWorker:
    def __init__(self, cfg: Settings, headless: bool = True):
        self.cfg = cfg
        self.headless = headless
        self.results_buffer = queue.Queue()
        self._stop_event = threading.Event()
        self._thread = None

    def push_result(self, res: InferenceResult):
        # keep most recent results if buffer full
        try:
            if self.results_buffer.full():
                try:
                    _ = self.results_buffer.get_nowait()
                except queue.Empty:
                    pass
            self.results_buffer.put_nowait(res)
        except queue.Full:
            pass

    def start(self):
        self._thread = threading.Thread(target=self._loop, daemon=False, name="Render")
        self._thread.start()

    def stop(self):
        self._stop_event.set()
        if self._thread:
            self._thread.join(timeout=1.0)

    def _loop(self):
        cv2.namedWindow("multi_player", cv2.WINDOW_NORMAL)
        while not self._stop_event.is_set():
            try:
                res: InferenceResult = self.results_buffer.get(timeout=0.5)
            except queue.Empty:
                continue
            frame = res.annotated_frame
            title = f"{res.url} #{res.seq}"
            if self.headless:
                cv2.imshow(title, frame)
                if cv2.waitKey(1) & 0xFF == ord('q'):
                    self._stop_event.set()
            else:
                # fallback to same behavior for now
                cv2.imshow(title, frame)
                if cv2.waitKey(1) & 0xFF == ord('q'):
                    self._stop_event.set()
        try:
            cv2.destroyAllWindows()
        except Exception:
            pass
        logger.info("Render stopped")
