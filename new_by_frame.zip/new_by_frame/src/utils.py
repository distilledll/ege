import time
import numpy as np
import cv2


def now_ts() -> float:
    return time.time()

def resize_keep_aspect(frame: np.ndarray, width: int) -> np.ndarray:
    h, w = frame.shape[:2]
    if w <= width:
        return frame
    scale = width / float(w)
    nh = int(h * scale)
    return cv2.resize(frame, (width, nh), interpolation=cv2.INTER_LINEAR)
