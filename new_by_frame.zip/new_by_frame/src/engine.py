from .capture import CaptureManager
from .scheduler import Scheduler
from .inference import InferencePool
from .render_tk import TkRender
from loguru import logger


class PipelineController:
    def __init__(self, cfg):
        self.cfg = cfg
        self.cap = None
        self.sched = None
        self.inf = None
        self.rnd = None

    def start(self, urls, grid_frame):
        logger.info("BOOT pipeline for {} streams", len(urls))

        self.cap = CaptureManager(urls, self.cfg)
        
        # Parse filter classes from config
        filter_classes = None
        if self.cfg.detect_classes:
            try:
                filter_classes = [int(x.strip()) for x in self.cfg.detect_classes.split(',') if x.strip()]
            except Exception:
                filter_classes = None
        
        self.inf = InferencePool(
            num_workers=self.cfg.num_workers,
            cfg=self.cfg,
            model_path=self.cfg.model_path,
            device=self.cfg.device,
            filter_classes=filter_classes,
        )
        self.rnd = TkRender(cfg=self.cfg, urls=urls, parent_frame=grid_frame)
        self.sched = Scheduler(self.cap, self.inf, self.rnd, self.cfg)

        self.cap.start_all()
        self.inf.start()
        self.rnd.start()
        self.sched.start()

    def stop(self):
        logger.info("Stopping pipeline...")
        if self.sched: self.sched.stop()
        if self.cap: self.cap.stop_all()
        if self.inf: self.inf.stop()
        if self.rnd: self.rnd.stop()
        logger.info("Stopped")
