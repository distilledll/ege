import threading
import queue
import time
from typing import Dict, List
from .models import InferenceResult
from .config import Settings
from loguru import logger
import tkinter as tk
from PIL import Image, ImageTk
import numpy as np
import cv2
import math


class CanvasSlot:
    def __init__(self, parent, row, col, title):
        self.frame = tk.Frame(parent, bd=1, relief=tk.RAISED, bg="black")
        self.frame.grid(row=row, column=col, padx=4, pady=4, sticky="nsew")
        # Truncate long URLs for display
        display_title = title if len(title) <= 70 else title[:67] + "..."
        self.title = display_title
        self.label = tk.Label(self.frame, text=display_title, bg="black", fg="white", font=("Arial", 8))
        self.label.pack(side=tk.TOP, anchor="w", fill="x")
        self.canvas = tk.Canvas(self.frame, bg="black", highlightthickness=0)
        self.canvas.pack(fill="both", expand=True)
        self.img_ref = None
        self.last_seq = -1
        self.meta_text = tk.StringVar()
        self.meta_label = tk.Label(self.frame, textvariable=self.meta_text, anchor="w", justify=tk.LEFT, bg="black", fg="gray", font=("Arial", 7))
        self.meta_label.pack(side=tk.BOTTOM, anchor="w", fill="x")
        
        # Track last frame for resizing
        self.last_frame = None
        self.last_meta = None
        
        # Bind canvas resize event
        self.canvas.bind("<Configure>", self._on_resize)
    
    def _on_resize(self, event):
        """Handle canvas resize - redraw last frame if available"""
        if self.last_frame is not None and self.last_meta is not None:
            self._draw_frame(self.last_frame, self.last_meta)

    def show_frame(self, frame: np.ndarray, meta: dict):
        self.last_frame = frame
        self.last_meta = meta
        self._draw_frame(frame, meta)
        
    def _draw_frame(self, frame: np.ndarray, meta: dict):
        # Get current canvas size
        canvas_width = self.canvas.winfo_width()
        canvas_height = self.canvas.winfo_height()
        
        # Skip if canvas not yet initialized
        if canvas_width <= 1 or canvas_height <= 1:
            return
            
        # BGR->RGB
        img = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        frame_h, frame_w = frame.shape[:2]
        
        # Calculate scaling to fit canvas while maintaining aspect ratio
        scale_w = canvas_width / frame_w
        scale_h = canvas_height / frame_h
        scale = min(scale_w, scale_h)  # Use min to fit inside (with potential black bars)
        
        new_w = int(frame_w * scale)
        new_h = int(frame_h * scale)
        
        # Resize image
        pil = Image.fromarray(img)
        try:
            resample = Image.Resampling.LANCZOS
        except AttributeError:
            resample = Image.LANCZOS if hasattr(Image, 'LANCZOS') else Image.BICUBIC
        pil = pil.resize((new_w, new_h), resample)
        
        tkimg = ImageTk.PhotoImage(pil)
        
        # Clear canvas and draw centered image
        self.canvas.delete("all")
        self.canvas.create_image(canvas_width//2, canvas_height//2, image=tkimg, anchor="center")
        self.img_ref = tkimg
        
        # Update metadata
        mt = f"seq:{meta.get('seq', '')} proc:{meta.get('proc_time', 0):.3f} model:{meta.get('model','')}"
        self.meta_text.set(mt)

class TkRender:
    def __init__(self, cfg: Settings, urls: List[str], parent_frame=None):
        self.cfg = cfg
        self.urls = urls
        self.results_buffer = queue.Queue()
        self._stop_event = threading.Event()
        self._thread = None
        self.root = None
        self.slots: Dict[str, CanvasSlot] = {}
        self.parent_frame = parent_frame  # Use existing frame if provided
        # layout params
        self.cols = min(4, max(1, int(math.sqrt(len(urls)))))

    def push_result(self, res: InferenceResult):
        try:
            if self.results_buffer.full():
                try:
                    _ = self.results_buffer.get_nowait()
                except queue.Empty:
                    pass
            self.results_buffer.put_nowait(res)
        except queue.Full:
            pass

    def start(self):
        if self.parent_frame:
            # Use existing parent frame - no separate window
            self._setup_in_parent()
        else:
            # Create separate window
            self._thread = threading.Thread(target=self._tk_loop, daemon=False, name="TkRender")
            self._thread.start()

    def stop(self):
        self._stop_event.set()
        if self.root and not self.parent_frame:
            try:
                self.root.quit()
            except Exception:
                pass
        if self._thread:
            self._thread.join(timeout=2.0)

    def _setup_in_parent(self):
        """Setup grid in existing parent frame"""
        # Get the root window from parent frame
        self.root = self.parent_frame.winfo_toplevel()
        
        # responsive grid
        rows = math.ceil(len(self.urls) / self.cols)
        for r in range(rows):
            self.parent_frame.rowconfigure(r, weight=1)
        for c in range(self.cols):
            self.parent_frame.columnconfigure(c, weight=1)

        # create slots
        for idx, url in enumerate(self.urls):
            r = idx // self.cols
            c = idx % self.cols
            slot = CanvasSlot(self.parent_frame, r, c, title=url)
            self.slots[url] = slot

        # Start pulling results
        self.root.after(50, self._pull_results)

    def _tk_loop(self):
        self.root = tk.Tk()
        self.root.title("Multi Player — RT-DETR")
        # responsive grid
        rows = math.ceil(len(self.urls) / self.cols)
        for r in range(rows):
            self.root.rowconfigure(r, weight=1)
        for c in range(self.cols):
            self.root.columnconfigure(c, weight=1)

        # create slots
        for idx, url in enumerate(self.urls):
            r = idx // self.cols
            c = idx % self.cols
            slot = CanvasSlot(self.root, r, c, title=url)
            self.slots[url] = slot

        self.root.after(50, self._pull_results)
        self.root.mainloop()

    def _pull_results(self):
        # called in tk mainloop context
        try:
            while not self.results_buffer.empty():
                res: InferenceResult = self.results_buffer.get_nowait()
                slot = self.slots.get(res.url)
                if slot:
                    slot.last_seq = res.seq
                    meta = {"seq": res.seq, **res.metadata}
                    slot.show_frame(res.annotated_frame, meta)
        except Exception as e:
            logger.exception("Render pull error: {}", e)
        if not self._stop_event.is_set():
            self.root.after(50, self._pull_results)
