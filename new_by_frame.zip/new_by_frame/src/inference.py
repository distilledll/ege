from concurrent.futures import ThreadPoolExecutor, Future
from multiprocessing import Manager
from typing import Dict, Optional, Tuple, Any, List
import queue
from .models import InferenceTask, InferenceResult, FramePacket
from .config import Settings
from loguru import logger
import numpy as np
import time
import traceback

# these globals live in worker threads
MODEL = None
MODEL_NAME = None
DEVICE = None
CLASS_NAMES = None

def _init_worker(model_path: str, device: str, imgsz: int):
    """
    initializer for worker: load model here once per thread
    """
    global MODEL, MODEL_NAME, DEVICE, CLASS_NAMES
    MODEL_NAME = model_path
    DEVICE = device
    try:
        # lazy import to keep master process light
        from ultralytics import YOLO
        logger.info(f"[worker] loading model {model_path} on {device}")
        MODEL = YOLO(model_path)
        # set device if supported
        try:
            MODEL.to(device)
        except Exception:
            pass
        # Get class names
        try:
            CLASS_NAMES = MODEL.names
        except Exception:
            CLASS_NAMES = {}
    except Exception as e:
        logger.exception("Failed to init model in worker: {}", e)
        MODEL = None
        CLASS_NAMES = {}

def _annotate_boxes(frame: np.ndarray, boxes: list, scores: list, labels: list) -> np.ndarray:
    import cv2
    out = frame.copy()
    for (x1, y1, x2, y2), s, lab in zip(boxes, scores, labels):
        cv2.rectangle(out, (int(x1), int(y1)), (int(x2), int(y2)), (0,255,0), 2)
        cv2.putText(out, f"{lab}:{s:.2f}", (int(x1), int(y1)-6), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0,255,0), 1)
    return out

def worker_process(payload: Tuple[str, int, float, np.ndarray, int, List[int]]):
    """
    payload: (url, seq, ts, frame, imgsz, filter_classes)
    Runs in worker thread; MODEL is expected to be loaded by initializer.
    """
    url, seq, ts, frame, imgsz, filter_classes = payload
    t0 = time.time()
    try:
        if MODEL is None:
            # fallback: simple text overlay
            import cv2
            f = frame.copy()
            cv2.putText(f, f"{url} #{seq} (no-model)", (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0,0,255), 2)
            meta = {"proc_time": time.time()-t0, "model": None}
            return (url, seq, ts, f, meta)
        # ultralytics: MODEL.predict accepts numpy arrays
        results = MODEL.predict(source=frame, imgsz=imgsz, conf=0.25, verbose=False)
        # results may be list-like; take first
        res0 = results[0]
        boxes = []
        scores = []
        labels = []
        # try to access boxes
        try:
            for b in res0.boxes:
                # Extract class ID correctly
                try:
                    # New API: cls is a tensor
                    cls_id = int(b.cls.item()) if hasattr(b.cls, 'item') else int(b.cls)
                except:
                    cls_id = int(b.cls)
                
                # Filter classes if specified
                if filter_classes is not None and len(filter_classes) > 0 and cls_id not in filter_classes:
                    continue
                
                # Get class name
                cls_name = CLASS_NAMES.get(cls_id, f"class_{cls_id}")
                
                # Extract xyxy properly
                if hasattr(b.xyxy, 'cpu'):
                    xyxy = b.xyxy.cpu().numpy().tolist()
                elif hasattr(b.xyxy, 'tolist'):
                    xyxy = b.xyxy.tolist()
                else:
                    xyxy = b.xyxy
                # Ensure it's a list of 4 values
                if isinstance(xyxy[0], list):
                    xyxy = xyxy[0]
                boxes.append(xyxy)
                
                # Extract confidence properly
                if hasattr(b.conf, 'cpu'):
                    conf_val = float(b.conf.cpu().numpy())
                elif hasattr(b.conf, '__getitem__'):
                    conf_val = float(b.conf[0])
                else:
                    conf_val = float(b.conf)
                scores.append(conf_val)
                
                labels.append(cls_name)
        except Exception:
            # older ultralytics API
            try:
                xyxy = res0.boxes.xyxy.cpu().numpy()
                confs = res0.boxes.conf.cpu().numpy()
                cls = res0.boxes.cls.cpu().numpy()
                for (x1,y1,x2,y2), c, cl in zip(xyxy, confs, cls):
                    cls_id = int(cl)
                    # Filter classes if specified
                    if filter_classes is not None and len(filter_classes) > 0 and cls_id not in filter_classes:
                        continue
                    cls_name = CLASS_NAMES.get(cls_id, f"class_{cls_id}")
                    boxes.append((x1,y1,x2,y2))
                    scores.append(float(c))
                    labels.append(cls_name)
            except Exception:
                boxes = []
                scores = []
                labels = []
        annotated = _annotate_boxes(frame, boxes, scores, labels) if len(boxes)>0 else frame
        meta = {"proc_time": time.time()-t0, "model": MODEL_NAME}
        return (url, seq, ts, annotated, meta)
    except Exception as e:
        tb = traceback.format_exc()
        logger.exception("Inference worker failed: {}", e)
        # on error return original frame with error overlay
        import cv2
        f = frame.copy()
        cv2.putText(f, f"ERR #{seq}", (10,30), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0,0,255), 2)
        meta = {"proc_time": time.time()-t0, "error": str(e), "trace": tb}
        return (url, seq, ts, f, meta)

class InferencePool:
    def __init__(self, num_workers: int, cfg: Settings, model_path: str = "rtdetr.pt", device: str = "cpu", filter_classes: Optional[List[int]] = None):
        self.num_workers = max(1, num_workers)
        self.cfg = cfg
        self.model_path = model_path
        self.device = device
        self.imgsz = cfg.frame_width
        self.filter_classes = filter_classes  # List of class IDs to filter, e.g. [0] for only people
        self.executor: Optional[ThreadPoolExecutor] = None
        self.results_q = queue.Queue(maxsize=100)  # Thread-safe queue
        self._started = False

    def start(self):
        if self._started:
            return
        logger.info(f"Starting InferencePool workers={self.num_workers} model={self.model_path} device={self.device} filter_classes={self.filter_classes}")
        # Use ThreadPoolExecutor instead of ProcessPoolExecutor to avoid multiprocessing issues
        self.executor = ThreadPoolExecutor(
            max_workers=self.num_workers,
            initializer=_init_worker,
            initargs=(self.model_path, self.device, self.imgsz)
        )
        self._started = True

    def submit(self, task: InferenceTask):
        if not self._started:
            raise RuntimeError("Pool not started")
        pkt: FramePacket = task.packet
        payload = (pkt.url, pkt.seq, pkt.ts, pkt.frame, self.imgsz, self.filter_classes)
        fut: Future = self.executor.submit(worker_process, payload)
        def _cb(f: Future):
            try:
                url, seq, ts, annotated, meta = f.result()
                res = InferenceResult(url=url, seq=seq, ts=ts, annotated_frame=annotated, metadata=meta)
                self.results_q.put(res)
            except Exception as e:
                logger.exception("Worker callback error: {}", e)
        fut.add_done_callback(_cb)
        return fut

    def get_result_queue(self):
        return self.results_q

    def stop(self):
        if not self._started:
            return
        try:
            self.executor.shutdown(wait=True)
        except Exception:
            pass
        self._started = False
        logger.info("InferencePool stopped")
